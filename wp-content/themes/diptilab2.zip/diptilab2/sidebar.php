<aside id="secondary" class="col-xs-12 col-md-3">
	<div id="sidebar">
		<?php
		if (is_active_sidebar('right-sidebar')) {
			dynamic_sidebar('right-sidebar');
		}
		?>
	</div>
</aside>